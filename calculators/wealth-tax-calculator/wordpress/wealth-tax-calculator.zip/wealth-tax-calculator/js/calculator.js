// Billionaire Wealth Tax Calculator — WordPress plugin script
// Element IDs are prefixed with "wtc-" to avoid collisions with other page content.

(function () {
    'use strict';

    // ── Constants ──────────────────────────────────────────────────────────────
    // Data is injected from WordPress via wp_localize_script
    var BILLIONAIRE_WEALTH = (typeof wealthTaxConfig !== 'undefined' && wealthTaxConfig.billionaireWealth) 
        ? wealthTaxConfig.billionaireWealth 
        : 15.3e12; // Fallback to $15.3 trillion

    // ── State ──────────────────────────────────────────────────────────────────
    var comparisonsData = (typeof wealthTaxConfig !== 'undefined' && wealthTaxConfig.comparisons)
        ? wealthTaxConfig.comparisons
        : [];
    var selectedPolicies = [];
    var selectedPolicyOptions = [];
    var collapsedPolicyGroups = [];
    var currentMode = 'basic'; // 'basic' or 'advanced'
    var TAX_RATE_MIN = 1;
    var TAX_RATE_MAX = 8;
    var sliderController = {
        instance: null,
        suppressCallback: false,
        resizeTicking: false
    };

    // Policy category labels
    var POLICY_LABELS = {
        healthcare: 'Healthcare',
        education: 'Education',
        business: 'Business',
        directRelief: 'Direct Relief',
        housing: 'Housing',
        childcare: 'Childcare & Families'
    };
    
    // Policy-specific funding examples
    var POLICY_EXAMPLES = {
        healthcare: [
            {
                minAmount: 25e9,
                maxAmount: 44e9,
                description: 'Expand Medicare to cover dental, vision, and hearing care for all seniors (~$29B/year)',
                sourceText: 'The Make Billionaires Pay Their Fair Share Act, Sen. Sanders (2026)',
                sourceUrl: 'https://www.sanders.senate.gov/wp-content/uploads/MakeBillionairesPayTheirFairShareAct.pdf'
            },
            {
                minAmount: 25e9,
                maxAmount: 44e9,
                description: 'Ensure all seniors and people with disabilities can receive Medicaid home health care (~$30B/year)',
                sourceText: 'The Make Billionaires Pay Their Fair Share Act, Sen. Sanders (2026)',
                sourceUrl: 'https://www.sanders.senate.gov/wp-content/uploads/MakeBillionairesPayTheirFairShareAct.pdf'
            },
            {
                minAmount: 45e9,
                maxAmount: 52e9,
                description: 'National Institutes of Health fully funded',
                sourceText: 'NIH Appropriations',
                sourceUrl: 'https://www.nih.gov/about-nih/nih-almanac/appropriations-section-1'
            },
            {
                minAmount: 100e9,
                maxAmount: 175e9,
                description: 'Reverse all Medicaid and ACA cuts from the One Big Beautiful Bill (~$110B/year)',
                sourceText: 'The Make Billionaires Pay Their Fair Share Act, Sen. Sanders (2026)',
                sourceUrl: 'https://www.sanders.senate.gov/wp-content/uploads/MakeBillionairesPayTheirFairShareAct.pdf'
            }
        ],
        education: [
            {
                minAmount: 13e9,
                maxAmount: 20e9,
                description: 'Guarantee a $60,000 minimum salary for all public school teachers nationwide (~$15B/year)',
                sourceText: 'The Make Billionaires Pay Their Fair Share Act, Sen. Sanders (2026)',
                sourceUrl: 'https://www.sanders.senate.gov/wp-content/uploads/MakeBillionairesPayTheirFairShareAct.pdf'
            }
        ],
        business: [],
        directRelief: [
            {
                minAmount: 900e9,
                maxAmount: 2000e9,
                description: 'Provide $3,000 direct payments to every person in households earning $150,000 or less',
                sourceText: 'The Make Billionaires Pay Their Fair Share Act, Sen. Sanders (2026)',
                sourceUrl: 'https://www.sanders.senate.gov/wp-content/uploads/MakeBillionairesPayTheirFairShareAct.pdf'
            }
        ],
        housing: [
            {
                minAmount: 80e9,
                maxAmount: 130e9,
                description: 'Build, rehabilitate, and preserve 700,000+ affordable homes per year to eliminate the housing gap (~$86B/year)',
                sourceText: 'The Make Billionaires Pay Their Fair Share Act, Sen. Sanders (2026)',
                sourceUrl: 'https://www.sanders.senate.gov/wp-content/uploads/MakeBillionairesPayTheirFairShareAct.pdf'
            }
        ],
        childcare: [
            {
                minAmount: 65e9,
                maxAmount: 110e9,
                description: 'Cap childcare costs at 7% of family income for all American families (~$70B/year)',
                sourceText: 'The Make Billionaires Pay Their Fair Share Act, Sen. Sanders (2026)',
                sourceUrl: 'https://www.sanders.senate.gov/wp-content/uploads/MakeBillionairesPayTheirFairShareAct.pdf'
            }
        ]
    };

    function getPolicyOptionKey(policy, index) {
        return policy + ':' + index;
    }

    function removePolicyOptionsForGroup(policyGroup) {
        var prefix = policyGroup + ':';
        selectedPolicyOptions = selectedPolicyOptions.filter(function (key) {
            return key.indexOf(prefix) !== 0;
        });
    }

    function removeCollapsedStateForGroup(policyGroup) {
        var index = collapsedPolicyGroups.indexOf(policyGroup);
        if (index > -1) {
            collapsedPolicyGroups.splice(index, 1);
        }
    }

    function updateAdvancedRevenueDisplay(taxRate, grossRevenue, selectedPolicyFunding) {
        var revenueAmountEl = el('wtc-revenueAmount');
        var taxExplanationEl = el('wtc-taxExplanation');
        var revenueSubtextEl = el('wtc-revenueSubtext');

        if (!revenueAmountEl || !taxExplanationEl || !revenueSubtextEl) return;

        if (currentMode === 'advanced' && selectedPolicyFunding > 0) {
            var remainingRevenue = Math.max(grossRevenue - selectedPolicyFunding, 0);
            taxExplanationEl.textContent =
                taxRate.toFixed(1) + '% of $15.3 trillion in billionaire wealth = ' + formatCurrency(grossRevenue) + ' total';
            revenueAmountEl.textContent = formatCurrency(remainingRevenue);
            revenueSubtextEl.textContent = formatCurrency(selectedPolicyFunding) + ' committed to selected policies';
            return;
        }

        taxExplanationEl.textContent = taxRate.toFixed(1) + '% of $15.3 trillion in billionaire wealth =';
        revenueAmountEl.textContent = formatCurrency(grossRevenue);
        revenueSubtextEl.textContent = '';
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    /**
     * Sanitize URL to prevent XSS attacks
     * Only allows http, https, and relative URLs
     */
    function sanitizeUrl(url) {
        if (!url) return '#';
        var urlStr = String(url).trim();
        // Allow http, https, and relative URLs only
        if (urlStr.match(/^(https?:\/\/|\/|#)/i)) {
            return urlStr;
        }
        return '#';
    }

    /**
     * Escape HTML to prevent XSS
     */
    function escapeHtml(text) {
        var div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    function formatCurrency(amount) {
        if (amount >= 1e12) {
            return '$' + (amount / 1e12).toFixed(2) + ' Trillion';
        }
        if (amount >= 1e9) {
            return '$' + (amount / 1e9).toFixed(1) + ' Billion';
        }
        return '$' + amount.toLocaleString('en-US', {
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        });
    }

    function calculateRevenue(taxRate) {
        return BILLIONAIRE_WEALTH * (taxRate / 100);
    }

    function getTaxRateInput() {
        return el('wtc-taxRate');
    }

    function clampTaxRate(value) {
        return Math.max(TAX_RATE_MIN, Math.min(TAX_RATE_MAX, value));
    }

    function quantizeTaxRate(value) {
        if (currentMode === 'basic') {
            return Math.round(value);
        }

        return Math.round(value * 10) / 10;
    }

    function rateToRatio(taxRate) {
        return (taxRate - TAX_RATE_MIN) / (TAX_RATE_MAX - TAX_RATE_MIN);
    }

    function clampRatio(value) {
        return Math.max(0, Math.min(1, value));
    }

    function ratioToRate(ratio) {
        return TAX_RATE_MIN + (clampRatio(ratio) * (TAX_RATE_MAX - TAX_RATE_MIN));
    }

    function getCurrentTaxRate() {
        var input = getTaxRateInput();
        if (!input) {
            return TAX_RATE_MIN;
        }

        var parsed = parseFloat(input.value);
        if (isNaN(parsed)) {
            return TAX_RATE_MIN;
        }

        return clampTaxRate(parsed);
    }

    function clampNumber(value, min, max) {
        return Math.max(min, Math.min(max, value));
    }

    function keepSliderInfoboxVisible() {
        var sliderWrapper = el('wtc-pr-slider');
        var sliderInfoBox = el('wtc-sliderInfobox');

        if (!sliderWrapper || !sliderInfoBox) {
            return;
        }

        var handleWrapper = sliderInfoBox.parentElement;
        if (!handleWrapper) {
            return;
        }

        sliderInfoBox.style.setProperty('--wtc-infobox-offset', '0px');
        sliderInfoBox.style.setProperty('--wtc-infobox-pointer-offset', '0px');

        var sliderRect = sliderWrapper.getBoundingClientRect();
        var handleRect = handleWrapper.getBoundingClientRect();
        var infoBoxWidth = sliderInfoBox.offsetWidth;

        if (!infoBoxWidth || sliderRect.width <= 0) {
            return;
        }

        var gutter = 8;
        var handleCenter = handleRect.left + (handleRect.width / 2);
        var desiredLeft = handleCenter - (infoBoxWidth / 2);
        var minLeft = sliderRect.left + gutter;
        var maxLeft = sliderRect.right - gutter - infoBoxWidth;
        var boundedLeft = clampNumber(desiredLeft, minLeft, maxLeft);
        var offset = boundedLeft - desiredLeft;

        var pointerLimit = (infoBoxWidth / 2) - 20;
        var pointerOffset = clampNumber(-offset, -pointerLimit, pointerLimit);

        sliderInfoBox.style.setProperty('--wtc-infobox-offset', offset.toFixed(2) + 'px');
        sliderInfoBox.style.setProperty('--wtc-infobox-pointer-offset', pointerOffset.toFixed(2) + 'px');
    }

    function syncSliderDecor(taxRate, revenue) {
        var sliderValue = el('wtc-sliderValue');
        var infoPrice = el('wtc-infoPrice');
        var annualPrice = el('wtc-annualPrice');
        var planHolder = el('wtc-plan-holder');
        var deviceHolder = el('wtc-device-holder');
        var highlightFill = el('wtc-highlight-fill');
        var handle = el('wtc-sliderHandle');

        var rateText = taxRate.toFixed(1) + '%';
        var progress = rateToRatio(taxRate) * 100;

        if (sliderValue) {
            sliderValue.textContent = rateText;
        }

        if (planHolder) {
            planHolder.textContent = 'Tax Rate:';
        }

        if (deviceHolder) {
            deviceHolder.textContent = rateText;
        }

        if (infoPrice) {
            infoPrice.textContent = formatCurrency(revenue);
        }

        if (annualPrice) {
            annualPrice.textContent = formatCurrency(revenue);
        }

        if (highlightFill) {
            highlightFill.style.width = progress.toFixed(2) + '%';
        }

        if (handle) {
            handle.setAttribute('aria-valuenow', taxRate.toFixed(1));
            handle.setAttribute('aria-valuetext', rateText);
        }

        var isAbdulRate = taxRate === 5;
        var dragdealer = el('wtc-pr-slider');
        var planBadge = el('wtc-planBadge');
        var handleSquare = el('wtc-sliderHandle');

        if (dragdealer) {
            if (isAbdulRate) {
                dragdealer.classList.add('is-rate-5');
            } else {
                dragdealer.classList.remove('is-rate-5');
            }
        }

        if (handleSquare) {
            if (isAbdulRate) {
                handleSquare.classList.add('is-rate-5');
            } else {
                handleSquare.classList.remove('is-rate-5');
            }
        }

        if (planBadge) {
            planBadge.style.display = isAbdulRate ? '' : 'none';
            planBadge.setAttribute('aria-hidden', isAbdulRate ? 'false' : 'true');
        }

        keepSliderInfoboxVisible();
    }

    function syncDragdealerPosition(taxRate) {
        if (!sliderController.instance) {
            return;
        }

        sliderController.suppressCallback = true;
        sliderController.instance.setValue(rateToRatio(taxRate), 0, true);
        sliderController.suppressCallback = false;
    }

    function setTaxRate(taxRate, syncHandlePosition) {
        var input = getTaxRateInput();
        if (!input) {
            return;
        }

        var nextRate = quantizeTaxRate(clampTaxRate(taxRate));
        input.value = currentMode === 'basic' ? String(Math.round(nextRate)) : nextRate.toFixed(1);

        if (syncHandlePosition) {
            syncDragdealerPosition(nextRate);
        }

        updateDisplay();
    }

    function handleSliderKeydown(event) {
        var key = event.key;
        var step = currentMode === 'basic' ? 1 : 0.1;
        var currentValue = getCurrentTaxRate();
        var nextValue = currentValue;

        if (key === 'ArrowLeft' || key === 'ArrowDown') {
            nextValue = currentValue - step;
        } else if (key === 'ArrowRight' || key === 'ArrowUp') {
            nextValue = currentValue + step;
        } else if (key === 'PageDown') {
            nextValue = currentValue - 1;
        } else if (key === 'PageUp') {
            nextValue = currentValue + 1;
        } else if (key === 'Home') {
            nextValue = TAX_RATE_MIN;
        } else if (key === 'End') {
            nextValue = TAX_RATE_MAX;
        } else {
            return;
        }

        event.preventDefault();
        setTaxRate(nextValue, true);
    }

    function initTaxRateSlider() {
        var sliderWrapper = el('wtc-pr-slider');
        var sliderHandle = el('wtc-sliderHandle');
        var taxRateInput = getTaxRateInput();

        if (!sliderWrapper || !sliderHandle || !taxRateInput || typeof Dragdealer === 'undefined') {
            return;
        }

        sliderController.instance = new Dragdealer('wtc-pr-slider', {
            x: rateToRatio(getCurrentTaxRate()),
            speed: 0.15,
            animationCallback: function (x) {
                if (sliderController.suppressCallback) {
                    return;
                }

                var nextRate = quantizeTaxRate(ratioToRate(x));
                var nextValue = currentMode === 'basic' ? String(Math.round(nextRate)) : nextRate.toFixed(1);

                if (taxRateInput.value !== nextValue) {
                    taxRateInput.value = nextValue;
                    updateDisplay();
                } else {
                    syncSliderDecor(nextRate, calculateRevenue(nextRate));
                }
            }
        });

        sliderHandle.addEventListener('keydown', handleSliderKeydown);
        syncDragdealerPosition(getCurrentTaxRate());

        function handleViewportChange() {
            if (sliderController.resizeTicking) {
                return;
            }

            sliderController.resizeTicking = true;
            window.requestAnimationFrame(function () {
                sliderController.resizeTicking = false;
                keepSliderInfoboxVisible();
            });
        }

        window.addEventListener('resize', handleViewportChange);
        window.addEventListener('orientationchange', handleViewportChange);
    }

    function findComparison(revenue) {
        if (!comparisonsData || comparisonsData.length === 0) {
            return {
                description: 'Comparison data loading…',
                sourceText: 'Loading…',
                sourceUrl: '#'
            };
        }

        for (var i = 0; i < comparisonsData.length; i++) {
            var c = comparisonsData[i];
            if (revenue >= c.minRevenue && revenue <= c.maxRevenue) {
                return c;
            }
        }

        // Revenue exceeds every defined range — use the last entry.
        return comparisonsData[comparisonsData.length - 1];
    }

    function updatePolicyAllocation() {
        var allocationResults = el('wtc-allocationResults');
        if (!allocationResults) return;

        var slider = el('wtc-taxRate');
        if (!slider) return;

        var taxRate = parseFloat(slider.value);
        var revenue = calculateRevenue(taxRate);
        var visiblePolicyOptionKeys = {};
        var selectedPolicyFunding = 0;

        if (selectedPolicies.length === 0) {
            selectedPolicyOptions = [];
            var prompt = document.createElement('p');
            prompt.className = 'allocation-prompt';
            prompt.textContent = 'Select categories above to see allocation';
            allocationResults.innerHTML = '';
            allocationResults.appendChild(prompt);
            updateAdvancedRevenueDisplay(taxRate, revenue, 0);
            return;
        }

        var amountPerCategory = revenue / selectedPolicies.length;
        allocationResults.innerHTML = ''; // Clear existing content

        for (var i = 0; i < selectedPolicies.length; i++) {
            var policy = selectedPolicies[i];
            var policyExamples = POLICY_EXAMPLES[policy] || [];
            var availableExamples = [];
            var isCollapsed = collapsedPolicyGroups.indexOf(policy) > -1;

            for (var j = 0; j < policyExamples.length; j++) {
                if (amountPerCategory >= policyExamples[j].minAmount) {
                    availableExamples.push({
                        example: policyExamples[j],
                        index: j
                    });
                }
            }

            var group = document.createElement('div');
            group.className = 'allocation-group';

            var groupToggle = document.createElement('button');
            groupToggle.type = 'button';
            groupToggle.className = 'allocation-group-toggle' + (isCollapsed ? ' collapsed' : '');
            groupToggle.setAttribute('data-policy', policy);
            groupToggle.setAttribute('aria-expanded', isCollapsed ? 'false' : 'true');

            var groupMain = document.createElement('span');
            groupMain.className = 'allocation-group-main';

            var category = document.createElement('span');
            category.className = 'allocation-category';
            category.textContent = POLICY_LABELS[policy] || policy;

            var amount = document.createElement('span');
            amount.className = 'allocation-amount';
            amount.textContent = formatCurrency(amountPerCategory);

            var chevron = document.createElement('span');
            chevron.className = 'allocation-group-chevron';
            chevron.setAttribute('aria-hidden', 'true');
            chevron.textContent = 'v';

            groupMain.appendChild(category);
            groupMain.appendChild(amount);
            groupToggle.appendChild(groupMain);
            groupToggle.appendChild(chevron);
            group.appendChild(groupToggle);

            var groupContent = document.createElement('div');
            groupContent.className = 'allocation-group-content' + (isCollapsed ? ' collapsed' : '');

            if (availableExamples.length > 0) {
                var examplesContainer = document.createElement('div');
                examplesContainer.className = 'allocation-example-list';

                for (var k = 0; k < availableExamples.length; k++) {
                    var available = availableExamples[k];
                    var exampleData = available.example;
                    var policyOptionKey = getPolicyOptionKey(policy, available.index);
                    var inputId = 'wtc-policyOption-' + policy + '-' + available.index;
                    var isChecked = selectedPolicyOptions.indexOf(policyOptionKey) > -1;

                    visiblePolicyOptionKeys[policyOptionKey] = true;
                    if (isChecked) {
                        selectedPolicyFunding += exampleData.minAmount;
                    }

                    var exampleRow = document.createElement('div');
                    exampleRow.className = 'allocation-example-row';

                    var optionLabel = document.createElement('label');
                    optionLabel.className = 'policy-option-checkbox';
                    optionLabel.setAttribute('for', inputId);

                    var optionInput = document.createElement('input');
                    optionInput.type = 'checkbox';
                    optionInput.className = 'policy-option-input';
                    optionInput.id = inputId;
                    optionInput.setAttribute('data-policy', policy);
                    optionInput.setAttribute('data-index', available.index);
                    if (isChecked) {
                        optionInput.checked = true;
                    }

                    var optionText = document.createElement('span');
                    optionText.className = 'policy-option-text';
                    optionText.textContent = exampleData.description;

                    optionLabel.appendChild(optionInput);
                    optionLabel.appendChild(optionText);

                    var optionMeta = document.createElement('div');
                    optionMeta.className = 'policy-option-meta';

                    var optionCost = document.createElement('span');
                    optionCost.className = 'policy-option-cost';
                    optionCost.textContent = formatCurrency(exampleData.minAmount);

                    var optionSource = document.createElement('a');
                    optionSource.href = sanitizeUrl(exampleData.sourceUrl);
                    optionSource.target = '_blank';
                    optionSource.rel = 'noopener noreferrer';
                    optionSource.className = 'example-source';
                    optionSource.textContent = 'source';

                    optionMeta.appendChild(optionCost);
                    optionMeta.appendChild(optionSource);

                    exampleRow.appendChild(optionLabel);
                    exampleRow.appendChild(optionMeta);
                    examplesContainer.appendChild(exampleRow);
                }

                groupContent.appendChild(examplesContainer);
            } else {
                var emptyMessage = document.createElement('p');
                emptyMessage.className = 'allocation-empty';
                emptyMessage.textContent = 'No policy options currently available for this category.';
                groupContent.appendChild(emptyMessage);
            }

            group.appendChild(groupContent);
            allocationResults.appendChild(group);
        }

        selectedPolicyOptions = selectedPolicyOptions.filter(function (key) {
            return !!visiblePolicyOptionKeys[key];
        });

        var remainingRevenue = Math.max(revenue - selectedPolicyFunding, 0);
        var summary = document.createElement('div');
        summary.className = 'allocation-summary';

        var selectedLine = document.createElement('span');
        selectedLine.textContent = 'Selected policy funding: ' + formatCurrency(selectedPolicyFunding);

        var remainingLine = document.createElement('span');
        remainingLine.textContent = 'Remaining revenue: ' + formatCurrency(remainingRevenue);

        summary.appendChild(selectedLine);
        summary.appendChild(remainingLine);
        allocationResults.appendChild(summary);

        var policyOptionCheckboxes = allocationResults.querySelectorAll('.policy-option-input');
        for (var n = 0; n < policyOptionCheckboxes.length; n++) {
            policyOptionCheckboxes[n].addEventListener('change', handlePolicyOptionChange);
        }

        var policyGroupToggles = allocationResults.querySelectorAll('.allocation-group-toggle');
        for (var p = 0; p < policyGroupToggles.length; p++) {
            policyGroupToggles[p].addEventListener('click', handlePolicyGroupToggle);
        }

        updateAdvancedRevenueDisplay(taxRate, revenue, selectedPolicyFunding);
    }

    function handlePolicyGroupToggle(event) {
        var policy = event.currentTarget.getAttribute('data-policy');
        var index = collapsedPolicyGroups.indexOf(policy);

        if (index > -1) {
            collapsedPolicyGroups.splice(index, 1);
        } else {
            collapsedPolicyGroups.push(policy);
        }

        updatePolicyAllocation();
    }

    function handlePolicyOptionChange(event) {
        var checkbox = event.target;
        var policy = checkbox.getAttribute('data-policy');
        var index = checkbox.getAttribute('data-index');
        var policyOptionKey = getPolicyOptionKey(policy, index);
        var existingIndex = selectedPolicyOptions.indexOf(policyOptionKey);

        if (checkbox.checked && existingIndex === -1) {
            selectedPolicyOptions.push(policyOptionKey);
        } else if (!checkbox.checked && existingIndex > -1) {
            selectedPolicyOptions.splice(existingIndex, 1);
        }

        updatePolicyAllocation();
    }

    function handlePolicyChange(event) {
        var checkbox = event.target;
        var policyValue = checkbox.value;
        var index = selectedPolicies.indexOf(policyValue);

        if (checkbox.checked && index === -1) {
            selectedPolicies.push(policyValue);
        } else if (!checkbox.checked && index > -1) {
            selectedPolicies.splice(index, 1);
            removePolicyOptionsForGroup(policyValue);
            removeCollapsedStateForGroup(policyValue);
        }

        updatePolicyAllocation();
    }

    function handleModeToggle(event) {
        var button = event.target;
        var mode = button.getAttribute('data-mode');
        
        if (mode === currentMode) return;
        
        currentMode = mode;
        
        // Update button states
        var modeButtons = document.querySelectorAll('.mode-button');
        for (var i = 0; i < modeButtons.length; i++) {
            var btn = modeButtons[i];
            if (btn.getAttribute('data-mode') === mode) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        }
        
        // Toggle policy allocation section visibility
        var policySection = document.querySelector('.policy-allocation-section');
        if (policySection) {
            if (mode === 'basic') {
                policySection.classList.add('hidden');
            } else {
                policySection.classList.remove('hidden');
            }
        }

        // Toggle revenue box visibility (hidden in basic, visible in advanced)
        var revenueBox = document.querySelector('.revenue-box');
        if (revenueBox) {
            if (mode === 'basic') {
                revenueBox.classList.add('hidden');
            } else {
                revenueBox.classList.remove('hidden');
            }
        }
        
        var currentValue = getCurrentTaxRate();

        if (mode === 'basic') {
            currentValue = Math.round(currentValue);
        }

        setTaxRate(currentValue, true);
    }

    // ── DOM ────────────────────────────────────────────────────────────────────

    function el(id) {
        return document.getElementById(id);
    }

    function updateDisplay() {
        var slider = getTaxRateInput();
        if (!slider) return;

        var taxRate = parseFloat(slider.value);
        if (isNaN(taxRate)) {
            taxRate = TAX_RATE_MIN;
        }

        var revenue = calculateRevenue(taxRate);

        el('wtc-rateDisplay') && (el('wtc-rateDisplay').textContent = taxRate.toFixed(1) + '%');
        syncSliderDecor(taxRate, revenue);
        updateAdvancedRevenueDisplay(taxRate, revenue, 0);

        var comparison = findComparison(revenue);
        el('wtc-comparisonText').textContent = comparison.description;

        var sourceEl = el('wtc-comparisonSource');
        var link = document.createElement('a');
        link.href = sanitizeUrl(comparison.sourceUrl);
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.textContent = comparison.sourceText;
        sourceEl.innerHTML = '';
        sourceEl.appendChild(link);

        // Update policy allocation
        updatePolicyAllocation();
    }

    // ── Bootstrap ──────────────────────────────────────────────────────────────

    function init() {
        var slider = getTaxRateInput();
        if (!slider) return; // Shortcode not present on this page.

        initTaxRateSlider();

        // Set up event listeners for policy checkboxes
        var policyCheckboxes = document.querySelectorAll('input[name="wtc-policy"]');
        for (var i = 0; i < policyCheckboxes.length; i++) {
            policyCheckboxes[i].addEventListener('change', handlePolicyChange);
        }

        // Set up event listeners for mode toggle buttons
        var modeButtons = document.querySelectorAll('.mode-button');
        for (var j = 0; j < modeButtons.length; j++) {
            modeButtons[j].addEventListener('click', handleModeToggle);
        }

        updateDisplay();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

}());
